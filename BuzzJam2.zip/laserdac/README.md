# VVVV.LaserDAC
was planned as:
Wrapper node around the universal laser DAC library (UDAC) of DrLava from http://www.photonlexicon.com/

but currently only EtherDream works.

